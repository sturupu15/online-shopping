package com.sales_order.sales_order.entity;

import jakarta.persistence.*;

@Entity
public class OrderLineItem {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String itemName;
    private Integer itemQuantity;

    @ManyToOne
    @JoinColumn(name = "order_id")
    private SalesOrder salesOrder;

    public OrderLineItem() {}

    public OrderLineItem(Long id, String itemName, Integer itemQuantity, SalesOrder salesOrder) {
        this.id = id;
        this.itemName = itemName;
        this.itemQuantity = itemQuantity;
        this.salesOrder = salesOrder;
    }

    // Getters and Setters

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getItemName() { return itemName; }
    public void setItemName(String itemName) { this.itemName = itemName; }

    public Integer getItemQuantity() { return itemQuantity; }
    public void setItemQuantity(Integer itemQuantity) { this.itemQuantity = itemQuantity; }

    public SalesOrder getSalesOrder() { return salesOrder; }
    public void setSalesOrder(SalesOrder salesOrder) { this.salesOrder = salesOrder; }

    @Override
    public String toString() {
        return "OrderLineItem{" +
                "id=" + id +
                ", itemName='" + itemName + '\'' +
                ", itemQuantity=" + itemQuantity +
                '}';
    }
    
}
