package com.sales_order.sales_order.entity;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
@Entity
public class SalesOrder {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDate orderDate;
    private Long custId;
    private String orderDesc;
    private Double totalPrice;

    @OneToMany(mappedBy = "salesOrder", cascade = CascadeType.ALL)
    private List<OrderLineItem> orderItems;

    public SalesOrder() {}

    public SalesOrder(Long id, LocalDate orderDate, Long custId, String orderDesc, Double totalPrice, List<OrderLineItem> orderItems) {
        this.id = id;
        this.orderDate = orderDate;
        this.custId = custId;
        this.orderDesc = orderDesc;
        this.totalPrice = totalPrice;
        this.orderItems = orderItems;
    }

    // Getters and Setters

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public LocalDate getOrderDate() { return orderDate; }
    public void setOrderDate(LocalDate orderDate) { this.orderDate = orderDate; }

    public Long getCustId() { return custId; }
    public void setCustId(Long custId) { this.custId = custId; }

    public String getOrderDesc() { return orderDesc; }
    public void setOrderDesc(String orderDesc) { this.orderDesc = orderDesc; }

    public Double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(Double totalPrice) { this.totalPrice = totalPrice; }

    public List<OrderLineItem> getOrderItems() { return orderItems; }
    public void setOrderItems(List<OrderLineItem> orderItems) { this.orderItems = orderItems; }

    @Override
    public String toString() {
        return "SalesOrder{" +
                "id=" + id +
                ", orderDate=" + orderDate +
                ", custId=" + custId +
                ", orderDesc='" + orderDesc + '\'' +
                ", totalPrice=" + totalPrice +
                '}';
    }
}
