package com.sales_order.sales_order.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.sales_order.sales_order.dto.OrderRequest;
import com.sales_order.sales_order.entity.SalesOrder;

import com.sales_order.sales_order.service.SalesOrderService;

@RestController
@RequestMapping("/orders")
public class SalesOrderController {

    @Autowired
    private SalesOrderService salesOrderService;

    @PostMapping
    public ResponseEntity<SalesOrder> createOrder(@RequestBody OrderRequest request) {
        SalesOrder order = salesOrderService.createOrder(
                request.getCustId(),
                request.getOrderDesc(),
                request.getItemName()
        );
        return ResponseEntity.ok(order);
    }

    @GetMapping("/customer/{custId}")
    public ResponseEntity<List<SalesOrder>> getOrdersByCustomer(@PathVariable Long custId) {
        return ResponseEntity.ok(salesOrderService.getOrdersByCustomer(custId));
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<SalesOrder> getOrderDetails(@PathVariable Long orderId) {
        return ResponseEntity.ok(salesOrderService.getOrderDetails(orderId));
    }
}