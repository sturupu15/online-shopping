package com.item_service.item_service;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Disabled
class ItemServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
