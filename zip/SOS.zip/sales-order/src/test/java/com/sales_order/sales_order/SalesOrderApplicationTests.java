package com.sales_order.sales_order;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Disabled
class SalesOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
