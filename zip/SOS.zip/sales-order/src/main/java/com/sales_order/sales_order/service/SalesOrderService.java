package com.sales_order.sales_order.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.sales_order.sales_order.dto.Customer;
import com.sales_order.sales_order.dto.Item;
import com.sales_order.sales_order.entity.CustomerSOS;

import com.sales_order.sales_order.entity.OrderLineItem;
import com.sales_order.sales_order.entity.SalesOrder;
import com.sales_order.sales_order.repository.CustomerSOSRepository;


import com.sales_order.sales_order.repository.SalesOrderRepository;

@Service
public class SalesOrderService {

    @Autowired
    private SalesOrderRepository salesOrderRepository;

    @Autowired
    private CustomerSOSRepository customerSOSRepository;

    @Autowired
    private RestTemplate restTemplate;

    public SalesOrder createOrder(Long custId, String orderDesc, List<String> itemNames) {
        // Step 1: Check in customer_sos table
        if (!customerSOSRepository.existsById(custId)) {
            String customerUrl = "http://customer-service/customer/" + custId;
            Customer customer = restTemplate.getForObject(customerUrl, Customer.class);

            if (customer == null || customer.getId() == null) {
                throw new RuntimeException("Customer not found with id: " + custId);
            }

            // Save to local CustomerSOS table
            CustomerSOS localCopy = new CustomerSOS(
                    customer.getId(),
                    customer.getFirstName(),
                    customer.getLastName(),
                    customer.getEmail()
            );
            customerSOSRepository.save(localCopy);
        }

        // Step 2: Validate items and calculate total
        List<OrderLineItem> orderLines = new ArrayList<>();
        double total = 0;

        for (String itemName : itemNames) {
            String itemUrl = "http://item-service/items/" + itemName;
            Item item = restTemplate.getForObject(itemUrl, Item.class);
            if (item == null) {
                throw new RuntimeException("Item not found: " + itemName);
            }

            OrderLineItem line = new OrderLineItem();
            line.setItemName(item.getName());
            line.setItemQuantity(1); // static 1
            orderLines.add(line);
            total += item.getPrice();
        }

        // Step 3: Create and persist order
        SalesOrder order = new SalesOrder();
        order.setCustId(custId);
        order.setOrderDesc(orderDesc);
        order.setOrderDate(LocalDate.now());
        order.setTotalPrice(total);
        order.setOrderItems(orderLines);

        for (OrderLineItem lineItem : orderLines) {
            lineItem.setSalesOrder(order);
        }

        return salesOrderRepository.save(order);
    }

    public List<SalesOrder> getOrdersByCustomer(Long custId) {
        return salesOrderRepository.findByCustId(custId);
    }

    public SalesOrder getOrderDetails(Long orderId) {
        return salesOrderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
    }
}