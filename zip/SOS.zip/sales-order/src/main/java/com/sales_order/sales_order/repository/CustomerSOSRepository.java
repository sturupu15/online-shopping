package com.sales_order.sales_order.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sales_order.sales_order.entity.CustomerSOS;

public interface CustomerSOSRepository extends JpaRepository<CustomerSOS, Long> {
}