package com.customer_service.customer_service;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Disabled
class CustomerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
